   

          ①  准备好你的网页文件夹（默认访问站点下的index.html，找不到文件会返回根目录下的404.html，请事先准备好）

          ②  打开bin文件夹，里面会找到三个文件：
                                        服务器、服务器+域名、开启映射
                服务器只提供http服务器功能，开启映射 提供域名，服务器+域名 提供http服务器功能和域名

          ③  注意，服务器的IP只能是127.0.0.1，端口任意（默认80）
     
          ④  服务器+域名 和 开启映射 都可以设置域名（注意是子域名），其中开启映射还须设置 端口号，这个端口就是 ③ 中服务器的端口

          ⑤  假如你在上面设置的子域名为 dsb，那么开启服务器后，在浏览器中输入 dsb.vaiwan.com，就能访问自己的网页了~






	提供一个网页模板：https://gitee.com/alice-wxp/MemoryLeakA.github.io/repository/archive/main.zip
	可到浏览器中下载
          © 2022 MemoryLeakA. All Rights Reserved.